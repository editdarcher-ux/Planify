package com.planify.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.planify.app.PlanifyViewModel
import com.planify.app.data.ItemType
import com.planify.app.ui.screens.*

private data class BottomDest(val route: String, val label: String, val icon: ImageVector)

@Composable
fun PlanifyApp(vm: PlanifyViewModel) {
    val nav = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    val bottom = remember {
        listOf(
            BottomDest("schedule", "Horario", Icons.Outlined.Schedule),
            BottomDest("calendar", "Calendario", Icons.Outlined.CalendarMonth),
            BottomDest("study", "Estudio", Icons.Outlined.Timer),
            BottomDest("settings", "Ajustes", Icons.Outlined.Settings)
        )
    }
    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "schedule"
    val editing = currentRoute.startsWith("edit")
    var addMenu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.messages.collect { msg ->
            val result = snackbar.showSnackbar(msg, if (msg.startsWith("Eliminado")) "Deshacer" else null)
            if (result == SnackbarResult.ActionPerformed) vm.undoDelete()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (!editing) {
                NavigationBar {
                    bottom.forEach { d ->
                        NavigationBarItem(
                            selected = currentRoute == d.route,
                            onClick = {
                                if (currentRoute != d.route) {
                                    addMenu = false
                                    nav.navigate(d.route) {
                                        popUpTo(nav.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(d.icon, null) },
                            label = { Text(d.label) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (!editing && currentRoute != "settings") {
                FloatingActionButton(onClick = { addMenu = true }) { Icon(Icons.Outlined.Add, "Añadir") }
                DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                    listOf(
                        ItemType.CLASS to "Clase",
                        ItemType.EXAM to "Examen",
                        ItemType.DELIVERY to "Entrega",
                        ItemType.TASK to "Tarea",
                        ItemType.EVENT to "Evento",
                        ItemType.REMINDER to "Recordatorio",
                        ItemType.OTHER to "Otro"
                    ).forEach { (type, label) ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            onClick = {
                                addMenu = false
                                nav.navigate("edit/new/${type.name}")
                            }
                        )
                    }
                }
            }
        }
    ) { inner ->
        androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.padding(inner)) {
            NavHost(navController = nav, startDestination = "schedule") {
                composable("schedule") {
                    ScheduleScreen(vm) { id -> nav.navigate("edit/$id") }
                }
                composable("calendar") {
                    CalendarScreen(vm) { id -> nav.navigate("edit/$id") }
                }
                composable("study") {
                    StudyScreen(vm) { id -> nav.navigate("edit/$id") }
                }
                composable("settings") {
                    SettingsScreen(vm)
                }
                composable(
                    "edit/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.LongType })
                ) { back ->
                    val id = back.arguments?.getLong("id")
                    EventEditorScreen(vm, id) { nav.popBackStack() }
                }
                composable(
                    "edit/new/{type}",
                    arguments = listOf(navArgument("type") { type = NavType.StringType })
                ) { back ->
                    val type = runCatching {
                        ItemType.valueOf(back.arguments?.getString("type") ?: ItemType.EVENT.name)
                    }.getOrDefault(ItemType.EVENT)
                    EventEditorScreen(vm, null, type) { nav.popBackStack() }
                }
            }
        }
    }
}
