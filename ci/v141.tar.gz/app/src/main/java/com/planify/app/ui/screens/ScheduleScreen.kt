package com.planify.app.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.planify.app.PlanifyViewModel
import com.planify.app.data.ItemType
import com.planify.app.domain.Occurrence
import com.planify.app.domain.RecurrenceEngine
import com.planify.app.ui.OccurrenceCard
import com.planify.app.util.dayName
import com.planify.app.util.minutesToText
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.ceil
import kotlin.math.floor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ScheduleScreen(vm: PlanifyViewModel, onOpen: (Long) -> Unit) {
    val all by vm.items.collectAsState()
    val settings by vm.settings.collectAsState()
    val context = LocalContext.current
    var grid by remember { mutableStateOf(true) }
    val prefs = remember { context.getSharedPreferences("planify_settings", android.content.Context.MODE_PRIVATE) }
    var imageUri by remember { mutableStateOf(prefs.getString("schedule_image_uri", null)) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.edit().putString("schedule_image_uri", uri.toString()).apply()
            imageUri = uri.toString()
        }
    }

    val bitmap by produceState<Bitmap?>(initialValue = null, imageUri) {
        value = if (imageUri.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            loadBitmap(context.applicationContext, imageUri)
        }
    }

    val today = LocalDate.now()
    val weekStart = today.with(TemporalAdjusters.previousOrSame(if (settings.firstDayMonday) DayOfWeek.MONDAY else DayOfWeek.SUNDAY))
    val classes = remember(all, weekStart) {
        RecurrenceEngine.occurrencesBetween(all.filter { it.type == ItemType.CLASS }, weekStart, weekStart.plusDays(6))
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Horario", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            FilterChip(selected = grid, onClick = { grid = true }, label = { Text("Cuadrícula") })
            Spacer(Modifier.width(6.dp))
            FilterChip(selected = !grid, onClick = { grid = false }, label = { Text("Lista") })
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Horario",
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 240.dp),
                        contentScale = ContentScale.Fit
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("Cambiar") }
                        OutlinedButton(onClick = {
                            prefs.edit().remove("schedule_image_uri").apply()
                            imageUri = null
                        }, modifier = Modifier.weight(1f)) { Text("Quitar") }
                    }
                } else {
                    Button(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Agregar imagen") }
                }
            }
        }

        if (classes.isNotEmpty()) {
            if (grid) {
                WeeklyGrid(classes, weekStart, settings.use24Hour, onOpen)
            } else {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    classes.forEach { occ -> OccurrenceCard(occ, settings.use24Hour, { onOpen(occ.item.id) }) }
                    Spacer(Modifier.height(80.dp))
                }
            }
        }
    }
}

@Composable
private fun WeeklyGrid(
    classes: List<Occurrence>,
    start: LocalDate,
    use24h: Boolean,
    onOpen: (Long) -> Unit
) {
    val earliest = classes.mapNotNull { it.item.startMinutes }.minOrNull() ?: 8 * 60
    val latest = classes.mapNotNull { it.item.endMinutes ?: it.item.startMinutes?.plus(60) }.maxOrNull() ?: 20 * 60
    val startHour = floor(earliest / 60.0).toInt().coerceAtMost(8).coerceAtLeast(5)
    val endHour = ceil(latest / 60.0).toInt().coerceAtLeast(20).coerceAtMost(24)
    val hourHeight = 64.dp
    val totalHeight = (64 * (endHour - startHour)).dp
    val vertical = rememberScrollState()
    val horizontal = rememberScrollState()

    Row(
        Modifier.fillMaxSize().horizontalScroll(horizontal).verticalScroll(vertical),
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.width(54.dp)) {
            Spacer(Modifier.height(44.dp))
            for (hour in startHour until endHour) {
                Text("%02d:00".format(hour), style = MaterialTheme.typography.labelSmall, modifier = Modifier.height(hourHeight))
            }
        }
        (0..6).forEach { i ->
            val date = start.plusDays(i.toLong())
            Column(Modifier.width(150.dp).padding(end = 8.dp)) {
                Column(Modifier.height(44.dp)) {
                    Text(date.dayName(), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${date.dayOfMonth}/${date.monthValue}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.height(totalHeight).fillMaxWidth()) {
                    classes.filter { it.date == date }.forEach { occ ->
                        val startMin = occ.item.startMinutes ?: startHour * 60
                        val endMin = occ.item.endMinutes ?: (startMin + 60)
                        val y = ((startMin - startHour * 60) / 60f * 64f).dp
                        val h = (((endMin - startMin).coerceAtLeast(30)) / 60f * 64f).dp.coerceAtLeast(40.dp)
                        Card(
                            onClick = { onOpen(occ.item.id) },
                            modifier = Modifier.offset(y = y).fillMaxWidth().height(h)
                        ) {
                            Column(Modifier.padding(8.dp)) {
                                Text(occ.item.title, style = MaterialTheme.typography.labelLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${minutesToText(occ.item.startMinutes, use24h)}–${minutesToText(occ.item.endMinutes, use24h)}", style = MaterialTheme.typography.labelSmall)
                                if (occ.item.location.isNotBlank()) Text(occ.item.location, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun loadBitmap(context: android.content.Context, uriString: String?): Bitmap? {
    val uri = uriString?.let(Uri::parse) ?: return null
    return runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    }.getOrNull()
}
