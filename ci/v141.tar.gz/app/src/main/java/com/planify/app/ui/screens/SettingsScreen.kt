package com.planify.app.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.planify.app.PlanifyViewModel
import com.planify.app.data.*
import com.planify.app.domain.RecurrenceEngine
import com.planify.app.util.PdfExporter
import com.planify.app.util.prettyDate
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

private enum class PdfMode(val label: String) {
    ALL("Todos los eventos"),
    EXAMS("Solo exámenes"),
    DELIVERIES("Solo entregas"),
    TASKS("Solo tareas"),
    SCHEDULE("Horario semanal"),
    WEEK("Planificación semanal"),
    MONTH("Planificación mensual"),
    RANGE("Entre dos fechas")
}

@Composable
fun SettingsScreen(vm: PlanifyViewModel) {
    val settings by vm.settings.collectAsState()
    val all by vm.items.collectAsState()
    val context = LocalContext.current
    var pendingBackup by remember { mutableStateOf<String?>(null) }
    var restoreText by remember { mutableStateOf<String?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var exportMode by remember { mutableStateOf(PdfMode.ALL) }
    var exportDialog by remember { mutableStateOf(false) }
    var rangeStart by remember { mutableStateOf(LocalDate.now()) }
    var rangeEnd by remember { mutableStateOf(LocalDate.now().plusMonths(1)) }
    var pendingPdfPlan by remember { mutableStateOf<Triple<List<com.planify.app.data.PlanItem>, LocalDate, LocalDate>?>(null) }
    var lastPdfUri by remember { mutableStateOf<Uri?>(null) }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val text = pendingBackup
        if (uri != null && text != null) context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
        pendingBackup = null
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        restoreText = uri?.let { context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() } }
        confirmRestore = restoreText != null
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val plan = pendingPdfPlan
        if (uri != null && plan != null) {
            val (source, from, to) = plan
            val occ = RecurrenceEngine.occurrencesBetween(source, from, to)
            context.contentResolver.openOutputStream(uri)?.use { out ->
                PdfExporter.export(out, occ, "Periodo: ${from.prettyDate()} – ${to.prettyDate()}")
            }
            lastPdfUri = uri
        }
        pendingPdfPlan = null
    }

    fun preparePdf() {
        val today = LocalDate.now()
        val monday = today.with(TemporalAdjusters.previousOrSame(if (settings.firstDayMonday) DayOfWeek.MONDAY else DayOfWeek.SUNDAY))
        val month = YearMonth.from(today)
        val earliest = all.minOfOrNull { it.dateEpochDay }?.let(LocalDate::ofEpochDay) ?: today
        val latestBase = all.maxOfOrNull { it.dateEpochDay }?.let(LocalDate::ofEpochDay) ?: today
        val hasRecurrence = all.any { it.repeatRule != RepeatRule.NONE }
        val allEnd = if (hasRecurrence) maxOf(latestBase, today.plusYears(1)) else latestBase
        val triple = when (exportMode) {
            PdfMode.ALL -> Triple(all, earliest, allEnd)
            PdfMode.EXAMS -> Triple(all.filter { it.type == ItemType.EXAM }, earliest, allEnd)
            PdfMode.DELIVERIES -> Triple(all.filter { it.type == ItemType.DELIVERY }, earliest, allEnd)
            PdfMode.TASKS -> Triple(all.filter { it.type == ItemType.TASK }, earliest, allEnd)
            PdfMode.SCHEDULE -> Triple(all.filter { it.type == ItemType.CLASS }, monday, monday.plusDays(6))
            PdfMode.WEEK -> Triple(all, monday, monday.plusDays(6))
            PdfMode.MONTH -> Triple(all, month.atDay(1), month.atEndOfMonth())
            PdfMode.RANGE -> Triple(all, minOf(rangeStart, rangeEnd), maxOf(rangeStart, rangeEnd))
        }
        pendingPdfPlan = triple
        val suffix = when (exportMode) {
            PdfMode.SCHEDULE -> "horario_semanal"
            PdfMode.WEEK -> "planificacion_semanal"
            PdfMode.MONTH -> "planificacion_mensual"
            else -> "planificacion_academica"
        }
        pdfLauncher.launch("$suffix.pdf")
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Apariencia", style = MaterialTheme.typography.titleMedium)
        SettingDropdown("Tema", themeLabel(settings.theme), ThemeMode.entries.map(::themeLabel)) { label ->
            vm.settingsStore.setTheme(ThemeMode.entries.first { themeLabel(it) == label })
        }
        SwitchRow("La semana empieza en lunes", settings.firstDayMonday) { vm.settingsStore.setFirstDayMonday(it) }
        SwitchRow("Formato de 24 horas", settings.use24Hour) { vm.settingsStore.setUse24Hour(it) }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Avisos", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Notificaciones", settings.notificationsEnabled) { vm.settingsStore.setNotifications(it) }
        SwitchRow("Sonido", settings.sound) { vm.settingsStore.setSound(it) }
        SwitchRow("Vibración", settings.vibration) { vm.settingsStore.setVibration(it) }
        SettingDropdown(
            "Duración predeterminada de clase",
            "${settings.defaultClassDuration} min",
            listOf("30 min", "45 min", "60 min", "90 min", "120 min")
        ) { value -> vm.settingsStore.setDefaultClassDuration(value.substringBefore(" ").toInt()) }
        SettingDropdown(
            "Recordatorio predeterminado",
            reminderSettingLabel(settings.defaultReminderMinutes),
            listOf(10, 30, 60, 180, 1440, 2880, 10080).map(::reminderSettingLabel)
        ) { value ->
            val options = listOf(10, 30, 60, 180, 1440, 2880, 10080)
            val selected = options.firstOrNull { reminderSettingLabel(it) == value } ?: 60
            vm.settingsStore.setDefaultReminder(selected)
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            OutlinedButton(onClick = { notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.fillMaxWidth()) { Text("Permitir notificaciones en Android") }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Colores de categorías", style = MaterialTheme.typography.titleMedium)
        listOf(ItemType.CLASS, ItemType.EXAM, ItemType.DELIVERY, ItemType.TASK, ItemType.REMINDER, ItemType.EVENT).forEach { type ->
            ColorPresetRow(type, settings.colorFor(type)) { vm.settingsStore.setCategoryColor(type, it) }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Datos", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { exportDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Exportar planificación a PDF") }
        lastPdfUri?.let { uri ->
            OutlinedButton(onClick = {
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runCatching { context.startActivity(view) }
            }, modifier = Modifier.fillMaxWidth()) { Text("Abrir último PDF") }
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(send, "Compartir PDF"))
            }, modifier = Modifier.fillMaxWidth()) { Text("Compartir último PDF") }
        }
        OutlinedButton(onClick = { vm.backupJson { text -> pendingBackup = text; backupLauncher.launch("planify_backup.json") } }, modifier = Modifier.fillMaxWidth()) { Text("Crear copia de seguridad") }
        OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("Restaurar copia de seguridad") }
        OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("Borrar todos los datos") }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Información", style = MaterialTheme.typography.titleMedium)
        Text("Planify 1.4.1 · Datos almacenados localmente · Sin cuenta obligatoria.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(80.dp))
    }

    if (exportDialog) AlertDialog(
        onDismissRequest = { exportDialog = false },
        title = { Text("Exportar PDF") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                PdfMode.entries.forEach { mode ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(mode.label, Modifier.weight(1f).padding(top = 12.dp))
                        RadioButton(selected = exportMode == mode, onClick = { exportMode = mode })
                    }
                }
                if (exportMode == PdfMode.RANGE) {
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d -> rangeStart = LocalDate.of(y, m + 1, d) }, rangeStart.year, rangeStart.monthValue - 1, rangeStart.dayOfMonth).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Desde: ${rangeStart.prettyDate()}") }
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, y, m, d -> rangeEnd = LocalDate.of(y, m + 1, d) }, rangeEnd.year, rangeEnd.monthValue - 1, rangeEnd.dayOfMonth).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Hasta: ${rangeEnd.prettyDate()}") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { exportDialog = false; preparePdf() }) { Text("Elegir ubicación") } },
        dismissButton = { TextButton(onClick = { exportDialog = false }) { Text("Cancelar") } }
    )

    if (confirmRestore) AlertDialog(
        onDismissRequest = { confirmRestore = false; restoreText = null },
        title = { Text("Restaurar copia") },
        text = { Text("La restauración sustituirá la planificación y preferencias actuales. ¿Quieres continuar?") },
        confirmButton = { TextButton(onClick = {
            val text = restoreText
            confirmRestore = false
            if (text != null) vm.restoreJson(text) { }
            restoreText = null
        }) { Text("Restaurar") } },
        dismissButton = { TextButton(onClick = { confirmRestore = false; restoreText = null }) { Text("Cancelar") } }
    )

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Borrar todos los datos") },
        text = { Text("Se eliminarán eventos, tareas, exámenes y clases guardados en este dispositivo.") },
        confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Borrar") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text, Modifier.weight(1f).padding(top = 12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingDropdown(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = { open = it }) {
        OutlinedTextField(value, {}, readOnly = true, label = { Text(label) }, modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable))
        ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); open = false }) }
        }
    }
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorPresetRow(type: ItemType, current: Long, onChange: (Long) -> Unit) {
    val presets = listOf(
        0xFF4E79A7, 0xFFD9534F, 0xFFF28E2B, 0xFFE3B341,
        0xFF59A14F, 0xFF7A6FF0, 0xFF26A69A, 0xFFEF5350,
        0xFFAB47BC, 0xFF5C6BC0, 0xFFFF7043, 0xFF8D6E63
    )
    val label = when (type) {
        ItemType.CLASS -> "Clases"
        ItemType.EXAM -> "Exámenes"
        ItemType.DELIVERY -> "Entregas"
        ItemType.TASK -> "Tareas"
        ItemType.REMINDER -> "Recordatorios y alarmas"
        else -> "Eventos"
    }
    var open by remember { mutableStateOf(false) }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Box(
                Modifier.size(16.dp)
                    .background(androidx.compose.ui.graphics.Color(current.toInt()), androidx.compose.foundation.shape.CircleShape)
            )
            Text(label)
        }
        TextButton(onClick = { open = true }) { Text("Cambiar color") }
    }

    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(label) },
            text = {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    presets.forEach { color ->
                        val selected = color == current
                        FilterChip(
                            selected = selected,
                            onClick = { onChange(color); open = false },
                            label = {
                                Box(
                                    Modifier.size(28.dp)
                                        .background(androidx.compose.ui.graphics.Color(color.toInt()), androidx.compose.foundation.shape.CircleShape)
                                )
                            }
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Cerrar") } }
        )
    }
}

private fun themeLabel(mode: ThemeMode) = when (mode) {
    ThemeMode.SYSTEM -> "Automático"
    ThemeMode.LIGHT -> "Claro"
    ThemeMode.DARK -> "Oscuro"
}

private fun reminderSettingLabel(minutes: Int): String = when (minutes) {
    10 -> "10 minutos antes"
    30 -> "30 minutos antes"
    60 -> "1 hora antes"
    180 -> "3 horas antes"
    1440 -> "1 día antes"
    2880 -> "2 días antes"
    10080 -> "1 semana antes"
    else -> "$minutes minutos antes"
}
