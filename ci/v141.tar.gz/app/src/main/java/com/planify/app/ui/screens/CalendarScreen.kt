package com.planify.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.planify.app.PlanifyViewModel
import com.planify.app.data.ItemType
import com.planify.app.domain.RecurrenceEngine
import com.planify.app.ui.EmptyState
import com.planify.app.ui.OccurrenceCard
import com.planify.app.util.prettyDate
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private enum class CalendarMode { MONTH, WEEK, DAY }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(vm: PlanifyViewModel, onOpen: (Long) -> Unit) {
    val all by vm.items.collectAsState()
    val settings by vm.settings.collectAsState()
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var mode by remember { mutableStateOf(CalendarMode.MONTH) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<ItemType?>(null) }
    var thisWeekOnly by remember { mutableStateOf(false) }
    var completedOnly by remember { mutableStateOf(false) }

    val filtered = remember(all, query, filter, thisWeekOnly, completedOnly, settings.firstDayMonday) {
        val weekStart = LocalDate.now().with(TemporalAdjusters.previousOrSame(if (settings.firstDayMonday) DayOfWeek.MONDAY else DayOfWeek.SUNDAY))
        val weekEnd = weekStart.plusDays(6)
        all.filter { item ->
            val baseDate = LocalDate.ofEpochDay(item.dateEpochDay)
            val queryMatch = query.isBlank() || item.title.contains(query, true) || item.subject.contains(query, true) ||
                baseDate.toString().contains(query, true) || baseDate.prettyDate().contains(query, true)
            val weekMatch = !thisWeekOnly || (baseDate in weekStart..weekEnd) || item.repeatRule != com.planify.app.data.RepeatRule.NONE
            val completeMatch = !completedOnly || item.taskStatus == com.planify.app.data.TaskStatus.COMPLETED
            (filter == null || item.type == filter) && queryMatch && weekMatch && completeMatch
        }
    }
    val selectedOccurrences = remember(filtered, selected) { RecurrenceEngine.occurrencesBetween(filtered, selected, selected) }

    Column(Modifier.fillMaxSize()) {
        SingleChoiceSegmentedButtonRow(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
            listOf(CalendarMode.MONTH to "Mes", CalendarMode.WEEK to "Semana", CalendarMode.DAY to "Día").forEachIndexed { i, (m, text) ->
                SegmentedButton(selected = mode == m, onClick = { mode = m }, shape = SegmentedButtonDefaults.itemShape(i, 3)) { Text(text) }
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
            placeholder = { Text("Buscar por nombre o asignatura") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                FilterRow(filter, thisWeekOnly, completedOnly,
                    onType = { filter = it }, onWeek = { thisWeekOnly = !thisWeekOnly }, onCompleted = { completedOnly = !completedOnly })
            }
            item {
                when (mode) {
                    CalendarMode.MONTH -> MonthCalendar(month, selected, filtered, settings.firstDayMonday,
                        onPrev = { month = month.minusMonths(1) }, onNext = { month = month.plusMonths(1) },
                        onSelect = { selected = it; month = YearMonth.from(it) })
                    CalendarMode.WEEK -> WeekPicker(selected, settings.firstDayMonday) { selected = it }
                    CalendarMode.DAY -> DayHeader(selected) { selected = selected.plusDays(it) }
                }
            }
            item { Text(selected.prettyDate(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
            if (selectedOccurrences.isEmpty()) item { EmptyState("No hay elementos para este día.") }
            items(selectedOccurrences, key = { "${it.item.id}-${it.date.toEpochDay()}" }) { occ ->
                OccurrenceCard(occ, settings.use24Hour, onClick = { onOpen(occ.item.id) })
            }
        }
    }
}

@Composable
private fun FilterRow(current: ItemType?, weekOnly: Boolean, completedOnly: Boolean, onType: (ItemType?) -> Unit, onWeek: () -> Unit, onCompleted: () -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = current == null, onClick = { onType(null) }, label = { Text("Todo") })
        listOf(ItemType.EXAM, ItemType.DELIVERY, ItemType.TASK, ItemType.CLASS, ItemType.EVENT).forEach { t ->
            val label = when(t) { ItemType.EXAM -> "Exámenes"; ItemType.DELIVERY -> "Entregas"; ItemType.TASK -> "Tareas"; ItemType.CLASS -> "Clases"; else -> "Eventos" }
            FilterChip(selected = current == t, onClick = { onType(t) }, label = { Text(label) })
        }
        FilterChip(selected = weekOnly, onClick = onWeek, label = { Text("Esta semana") })
        FilterChip(selected = completedOnly, onClick = onCompleted, label = { Text("Completadas") })
    }
}

@Composable
private fun MonthCalendar(
    month: YearMonth,
    selected: LocalDate,
    items: List<com.planify.app.data.PlanItem>,
    mondayFirst: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onSelect: (LocalDate) -> Unit
) {
    val locale = Locale("es", "ES")
    val firstDay = if (mondayFirst) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
    val first = month.atDay(1)
    val offset = ((first.dayOfWeek.value - firstDay.value) + 7) % 7
    val days = List(offset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val markedDays = remember(items, month) {
        RecurrenceEngine.occurrencesBetween(items, month.atDay(1), month.atEndOfMonth())
            .asSequence()
            .map { it.date }
            .toHashSet()
    }
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrev) { Icon(Icons.Outlined.ChevronLeft, "Mes anterior") }
            Text(month.month.getDisplayName(TextStyle.FULL, locale).replaceFirstChar { it.titlecase(locale) } + " ${month.year}", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = onNext) { Icon(Icons.Outlined.ChevronRight, "Mes siguiente") }
        }
        Row(Modifier.fillMaxWidth()) {
            (0..6).map { firstDay.plus(it.toLong()) }.forEach { d ->
                Text(d.getDisplayName(TextStyle.SHORT, locale).take(2), Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
            }
        }
        val rows = (days.size + 6) / 7
        Column(Modifier.height((rows * 48).dp)) {
            LazyVerticalGrid(columns = GridCells.Fixed(7), userScrollEnabled = false) {
                gridItems(days) { day ->
                    if (day == null) Spacer(Modifier.height(48.dp)) else {
                        val has = day in markedDays
                        Box(Modifier.height(48.dp).clickable { onSelect(day) }, contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(30.dp).clip(CircleShape)
                                        .background(if (day == selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent),
                                    contentAlignment = Alignment.Center
                                ) { Text(day.dayOfMonth.toString()) }
                                if (has) Box(Modifier.size(4.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekPicker(selected: LocalDate, mondayFirst: Boolean, onSelect: (LocalDate) -> Unit) {
    val startDow = if (mondayFirst) DayOfWeek.MONDAY else DayOfWeek.SUNDAY
    val start = selected.with(TemporalAdjusters.previousOrSame(startDow))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        (0..6).forEach { i ->
            val d = start.plusDays(i.toLong())
            FilterChip(selected = d == selected, onClick = { onSelect(d) }, label = { Text("${d.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale("es"))}\n${d.dayOfMonth}") })
        }
    }
}

@Composable
private fun DayHeader(selected: LocalDate, move: (Long) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { move(-1) }) { Icon(Icons.Outlined.ChevronLeft, "Día anterior") }
        Text(selected.prettyDate(), Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
        IconButton(onClick = { move(1) }) { Icon(Icons.Outlined.ChevronRight, "Día siguiente") }
    }
}
