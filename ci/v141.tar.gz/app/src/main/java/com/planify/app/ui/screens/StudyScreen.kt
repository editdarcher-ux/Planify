package com.planify.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.planify.app.PlanifyViewModel
import com.planify.app.data.ItemType
import com.planify.app.data.TaskStatus
import com.planify.app.ui.EmptyState
import com.planify.app.ui.TaskRow
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private class TimerEntry(id: Int) {
    val id: Int = id
    var minutesText by mutableStateOf("10")
    var remainingSeconds by mutableStateOf(10 * 60)
    var running by mutableStateOf(false)
}

@Composable
fun StudyScreen(vm: PlanifyViewModel, onOpen: (Long) -> Unit) {
    val all by vm.items.collectAsState()
    val settings by vm.settings.collectAsState()
    val tasks = remember(all) {
        all.filter { it.type == ItemType.TASK || it.type == ItemType.DELIVERY }
            .sortedWith(compareBy({ it.taskStatus == TaskStatus.COMPLETED }, { it.dateEpochDay }, { it.startMinutes ?: 0 }))
    }

    var studyMinutesText by remember { mutableStateOf("25") }
    var breakMinutesText by remember { mutableStateOf("5") }
    var cyclesText by remember { mutableStateOf("4") }
    var pomodoroRunning by remember { mutableStateOf(false) }
    var pomodoroBreak by remember { mutableStateOf(false) }
    var pomodoroCompleted by remember { mutableStateOf(0) }
    var pomodoroRemaining by remember { mutableStateOf(25 * 60) }

    val studyMinutes = studyMinutesText.toIntOrNull()?.coerceIn(1, 180) ?: 25
    val breakMinutes = breakMinutesText.toIntOrNull()?.coerceIn(1, 120) ?: 5
    val cycles = cyclesText.toIntOrNull()?.coerceIn(1, 100) ?: 4

    fun resetPomodoro() {
        pomodoroRunning = false
        pomodoroBreak = false
        pomodoroCompleted = 0
        pomodoroRemaining = studyMinutes * 60
    }

    LaunchedEffect(pomodoroRunning, studyMinutes, breakMinutes, cycles) {
        while (pomodoroRunning && isActive) {
            delay(1000)
            if (pomodoroRemaining > 0) pomodoroRemaining -= 1
            if (pomodoroRemaining <= 0) {
                if (!pomodoroBreak) {
                    pomodoroCompleted += 1
                    if (pomodoroCompleted >= cycles) {
                        pomodoroRunning = false
                        pomodoroBreak = false
                        pomodoroRemaining = 0
                    } else {
                        pomodoroBreak = true
                        pomodoroRemaining = breakMinutes * 60
                    }
                } else {
                    pomodoroBreak = false
                    pomodoroRemaining = studyMinutes * 60
                }
            }
        }
    }

    val timers = remember { mutableStateListOf<TimerEntry>() }
    var timerId by remember { mutableIntStateOf(1) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ClockText()

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pomodoro", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(if (pomodoroBreak) "Descanso" else "Estudio", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(formatSeconds(pomodoroRemaining), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("${pomodoroCompleted.coerceAtMost(cycles)}/$cycles", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CompactNumberField("Estudio", studyMinutesText, { studyMinutesText = it.filter(Char::isDigit).take(3); if (!pomodoroRunning && !pomodoroBreak) pomodoroRemaining = (studyMinutesText.toIntOrNull()?.coerceIn(1, 180) ?: 25) * 60 }, Modifier.weight(1f))
                    CompactNumberField("Descanso", breakMinutesText, { breakMinutesText = it.filter(Char::isDigit).take(3) }, Modifier.weight(1f))
                    CompactNumberField("Pomodoros", cyclesText, { cyclesText = it.filter(Char::isDigit).take(3) }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            if (pomodoroRemaining <= 0) pomodoroRemaining = if (pomodoroBreak) breakMinutes * 60 else studyMinutes * 60
                            pomodoroRunning = !pomodoroRunning
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(if (pomodoroRunning) "Pausar" else "Iniciar") }
                    OutlinedButton(onClick = ::resetPomodoro, modifier = Modifier.weight(1f)) { Text("Reiniciar") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Temporizadores", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = {
                        timers.add(TimerEntry(timerId++))
                    }) { Text("Agregar") }
                }
                if (timers.isEmpty()) {
                    Text("", style = MaterialTheme.typography.bodySmall)
                }
                timers.forEach { timer ->
                    TimerEntryCard(timer = timer, onDelete = { timers.remove(timer) })
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Tareas", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (tasks.isEmpty()) {
                    EmptyState("Sin tareas")
                } else {
                    tasks.forEach { item ->
                        TaskRow(
                            item = item,
                            onToggle = { vm.markTask(item, if (item.taskStatus == TaskStatus.COMPLETED) TaskStatus.PENDING else TaskStatus.COMPLETED) },
                            onClick = { onOpen(item.id) },
                            use24h = settings.use24Hour
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun ClockText() {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalTime.now()
            delay(1000)
        }
    }
    Text(
        now.format(DateTimeFormatter.ofPattern("HH:mm:ss")),
        style = MaterialTheme.typography.headlineLarge,
        fontWeight = FontWeight.SemiBold
    )
}

@Composable
private fun TimerEntryCard(timer: TimerEntry, onDelete: () -> Unit) {
    val minutes = timer.minutesText.toIntOrNull()?.coerceIn(1, 1440) ?: 10

    LaunchedEffect(timer.running) {
        while (timer.running && timer.remainingSeconds > 0 && isActive) {
            delay(1000)
            timer.remainingSeconds -= 1
        }
        if (timer.running && timer.remainingSeconds <= 0) timer.running = false
    }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CompactNumberField("Min", timer.minutesText, {
                    timer.minutesText = it.filter(Char::isDigit).take(4)
                    if (!timer.running) timer.remainingSeconds = (timer.minutesText.toIntOrNull()?.coerceIn(1, 1440) ?: 10) * 60
                }, Modifier.weight(1f))
                Text(formatSeconds(timer.remainingSeconds), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    if (timer.remainingSeconds <= 0) timer.remainingSeconds = minutes * 60
                    timer.running = !timer.running
                }, modifier = Modifier.weight(1f)) { Text(if (timer.running) "Pausar" else "Iniciar") }
                OutlinedButton(onClick = { timer.running = false; timer.remainingSeconds = minutes * 60 }, modifier = Modifier.weight(1f)) { Text("Reiniciar") }
                TextButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Quitar") }
            }
        }
    }
}

@Composable
private fun CompactNumberField(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier
    )
}

private fun formatSeconds(total: Int): String {
    val safe = total.coerceAtLeast(0)
    val h = safe / 3600
    val m = (safe % 3600) / 60
    val s = safe % 60
    return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
